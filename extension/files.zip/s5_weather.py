"""S5 - 기상청 단기예보 API 연동 검증.

공공데이터포털(data.go.kr)에서 '기상청_단기예보 조회서비스' 활용신청 후
발급받은 서비스 키를 .env 의 KMA_SERVICE_KEY 에 넣고 실행한다.

통과 기준: 두 구장 모두 POP(강수확률)와 TMP(기온) 정상 수신
"""
from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone

import requests
from dotenv import load_dotenv

load_dotenv()
KST = timezone(timedelta(hours=9))
ENDPOINT = ("https://apis.data.go.kr/1360000/VilageFcstInfoService_2.0"
            "/getVilageFcst")

# 기상청 격자 좌표(nx, ny). 위경도가 아니라 격자값을 쓴다.
# 아래 값은 미검증 추정치이므로, 결과가 이상하면 기상청 격자표로 대조할 것.
GRID = {
    "라팍": {"nx": 89, "ny": 90},
    "잠실": {"nx": 62, "ny": 126},
}


def base_datetime() -> tuple[str, str]:
    """단기예보 발표 시각 중 가장 최근 것을 반환한다.

    발표는 02/05/08/11/14/17/20/23시이며 약 10분 뒤부터 조회 가능하다.
    """
    now = datetime.now(KST) - timedelta(minutes=45)
    slots = [23, 20, 17, 14, 11, 8, 5, 2]
    for h in slots:
        if now.hour >= h:
            return now.strftime("%Y%m%d"), f"{h:02d}00"
    prev = now - timedelta(days=1)
    return prev.strftime("%Y%m%d"), "2300"


def fetch(name: str, nx: int, ny: int, key: str) -> dict[str, str]:
    """해당 격자의 POP/TMP/SKY/PTY 최근값을 반환한다.

    Raises:
        RuntimeError: API가 정상 응답을 주지 않은 경우.
    """
    base_date, base_time = base_datetime()
    params = {
        "serviceKey": key,
        "numOfRows": 300,
        "pageNo": 1,
        "dataType": "JSON",
        "base_date": base_date,
        "base_time": base_time,
        "nx": nx,
        "ny": ny,
    }

    try:
        r = requests.get(ENDPOINT, params=params, timeout=10)
        r.raise_for_status()
        body = r.json()
    except Exception as exc:
        raise RuntimeError(f"{name} 요청 실패: {exc}") from exc

    header = body.get("response", {}).get("header", {})
    if header.get("resultCode") not in ("00", "0"):
        raise RuntimeError(f"{name} API 오류: {header}")

    items = body["response"]["body"]["items"]["item"]
    out: dict[str, str] = {}
    for it in items:
        cat = it["category"]
        if cat in ("POP", "TMP", "SKY", "PTY") and cat not in out:
            out[cat] = f"{it['fcstValue']} ({it['fcstDate']} {it['fcstTime']})"
    return out


if __name__ == "__main__":
    print("=" * 56)
    print("S5  기상청 단기예보 API 연동 검증")
    print("=" * 56)

    key = os.getenv("KMA_SERVICE_KEY")
    if not key:
        print("\n실패: .env 에 KMA_SERVICE_KEY 가 없습니다.")
        print("https://www.data.go.kr 에서 '기상청_단기예보 조회서비스' 활용신청 후")
        print(".env 파일에 KMA_SERVICE_KEY=발급키 형식으로 넣어주세요.")
        raise SystemExit(1)

    bd, bt = base_datetime()
    print(f"\n기준 발표시각: {bd} {bt}\n")

    ok = True
    for name, g in GRID.items():
        try:
            res = fetch(name, g["nx"], g["ny"], key)
            print(f"  [{name}] nx={g['nx']} ny={g['ny']}")
            for k in ("TMP", "POP", "SKY", "PTY"):
                label = {"TMP": "기온", "POP": "강수확률",
                         "SKY": "하늘상태", "PTY": "강수형태"}[k]
                print(f"    {label:<6}: {res.get(k, '없음')}")
            if "POP" not in res or "TMP" not in res:
                ok = False
        except RuntimeError as exc:
            print(f"  [{name}] 실패: {exc}")
            ok = False
        print()

    print(f"  판정: {'통과' if ok else '미달'}")
    raise SystemExit(0 if ok else 1)
